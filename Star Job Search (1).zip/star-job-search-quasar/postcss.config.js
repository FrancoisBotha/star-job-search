export default {
  plugins: [
    // https://github.com/postcss/autoprefixer
    require('autoprefixer')({
      overrideBrowserslist: ['last 4 Chrome versions', 'last 4 Firefox versions', 'last 4 Edge versions', 'last 4 Safari versions'],
    }),
  ],
};
