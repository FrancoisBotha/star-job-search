/**
 * Electron preload. Expose safe, typed bridges to the renderer here
 * (e.g. CV file picking, backup-folder selection, secure key storage).
 */
// import { contextBridge } from 'electron';

// contextBridge.exposeInMainWorld('star', {
//   chooseBackupFolder: () => ipcRenderer.invoke('star:chooseBackupFolder'),
//   pickCv: () => ipcRenderer.invoke('star:pickCv'),
// });
